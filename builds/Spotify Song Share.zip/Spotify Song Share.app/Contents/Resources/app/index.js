var menubar = require('menubar');

var mb = menubar({
    dir: __dirname,
    width: 405,
    height: 55
});
